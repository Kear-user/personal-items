<template>
  <div class="hello">
    <h1>{{ msg }}</h1>  <!--这里是展示数据中的 -->
  </div>
</template>

<script>
export default {
  data () {
    return {
      msg: 'Kear-Vue',  /* 这里是数据，一定记住数据一定要放data中然后用return返回 */
      msg2: '哈哈哈哈'
    }
  }
}

/*在vue组件中，调取数据
  created () {
      
      // 方式一
      // 使用node中的express
      this.$http.get('/api/goods').then((data) => {
        if(data.body.code == 0){
          this.imgArr = data.body.data;
          console.log(this.imgArr)
        }
      })
    
      //  方式二
      //  使用json-server方式
      this.$http.get('http://localhost:8080/api/goods').then((data) => {
       console.log(data.body)
      if(data.body.code == 0){
         this.imgArr = data.body.body;
         console.log(this.imgArr)
        }
      })
   }*/
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped> /* scoped的意思是这里的样式只对当前页面有效不会影响其他页面，还有可以设置lang="scss"就是支持css预编译，也就是支持sass或者less  */
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
