<template>
  <div id="app">
    <img src="./assets/logo.png"> 
    <router-view/> <!--  这里是用来展示路由页面内容的，如果想用跳转就用<router-link to='xxx'></router-link> -->
    <input v-model="newItem" v-on:keyup.enter="addNew" />
    <ul>
      <li v-bind:class="{underline: item.isUnderline}"  v-for="item in items" v-on:click="doThing(item)"> 
        {{ item.name }} 
      </li>
    </ul>
  </div>
</template>

<script>
import Store from './store.js'

export default {
   data () {
    return {
      items:Store.fetch(),
      newItem:''
    }
  },
  watch:{
    items:{
      handler:function(items){
        Store.save(items)
      },
      deep:true
    }
  },
  methods:{
    doThing: function (item) {
      item.isUnderline = !item.isUnderline
    },
    addNew: function (){
      this.items.push({
        name: this.newItem,
        isUnderline:false
      })
      this.newItem =''
    }
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.underline{
  text-decoration: underline;
}
</style>
