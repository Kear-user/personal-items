<template>
  <div id="app">
    <div id="app-head">
      <Header/>
    </div>
    <div id="app-body">
      <router-view/>
    </div>
    <div id="app-foot">
      <Footer/>
    </div>
  </div>
</template>

<script>
import Header from './components/header/Header'
import Footer from './components/footer/Footer'

export default {
  name: 'App',
  data () {
    return {
    }
  },
  mounted () {
  },
  methods: {
  },
  components: {
    Header,
    Footer
  }
}
</script>

<style scoped lang="scss">
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  width: 100%;
  height: 100%;
}
#app-head {
  // height: 200px;
  // background-color: orange;
}
#app-body {
  height: 200px;
  background-color: #01cdb2;
}
#app-foot {
  height: 200px;
  background-color: orangered;
}
</style>
