<template>
  <div>
    <header id="home-header">
        <div class="content">
            <div class="logo"></div>
            <div class="logoSaying"></div>
            <div id="kefu">
                <div id="kefu-qq">
                    <img src="images/qqIcon.png" alt="">
                    在线客服
                </div>
                <div id="kefu-weChat">
                    <img src="images/weChatIcon.png" alt="">
                    官方微信
                </div>
            </div>
            <el-input class="searchInput"
              placeholder="请输入内容"
              suffix-icon="el-icon-search"
              v-model="input6">
            </el-input>
        </div>
    </header>
    <div class="">
      <el-menu class="el-menu-demo" mode="horizontal">
        <el-menu-item index="1" @click="toPath('index')">首页</el-menu-item>
        <el-menu-item index="2" @click="toPath('order')">个人中心</el-menu-item>
        <el-menu-item index="3" @click="toPath('order')">订单管理</el-menu-item>
      </el-menu>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: ''
    }
  },
  methods: {
    toPath (path) {
      if (path) {
        this.$router.replace('/' + path)
      }
    }
  }
}
</script>

<style scoped lang="scss">
#home-header{
  height: 100%;
  width: 100%;
  background: url('images/headerBg.png') no-repeat center/cover;
  & .content{
    overflow: hidden;
    height: 90px;
    width: 1100px;
    margin: 0 auto;
    position: relative;
  }
  & .logo{
    height: 50px;
    width: 120px;
    margin-top: 20px;
    float: left;
    background: url('images/logo.png') no-repeat center/cover;
  }
  & .logoSaying{
    position: absolute;
    height: 26px;
    width: 154px;
    left: 140px;
    background: url('images/logoSaying.png') no-repeat center/cover;
    top: 35px;
  }
  & #kefu{
    position: absolute;
    right: 200px;
    top: 36px;
    width: 150px;
    height: 20px;
    font-size: 12px;
    color: #8f8f8f;
  }
  & #kefu-qq{
    width: 70px;
    height: 100%;
    float: left;
  }
  & #kefu-qq img{
    width: 11px;
    height: 12px;
    position: relative;
    top: 1px;
  }
  & #kefu-weChat{
    width: 70px;
    height: 100%;
    float: left;
  }
  & #kefu-weChat img{
    width: 15px;
    height: 13px;
    position: relative;
    top: 2px;
  }
  & .searchInput{
    width: 177px;
    height: 32px;
    position: absolute;
    right: 0;
    top: 25px;
  }
}
</style>
