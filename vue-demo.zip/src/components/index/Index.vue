<template>
  <div class="index">i'm Index</div>
</template>

<script>
export default {
  name: 'Index',
  data () {
    return {
      msg: ''
    }
  }
}
</script>

<style scoped lang="scss">
</style>
