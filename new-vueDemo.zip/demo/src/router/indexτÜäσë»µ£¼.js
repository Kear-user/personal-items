import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/components/index/Index'
import Example from '@/components/example/Example'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Example',
      component: Example
    },
    {
      path: '/index',
      name: 'Index',
      component: Index
    },
    {
      path: '/example',
      name: 'Example',
      component: Example
    }
  ]
})
