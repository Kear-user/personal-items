<template>
  <div class="index">i'm Index {{string.example.name}}</div>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  name: 'Index',
  computed: {
    ...mapGetters([
      'string'
    ])
  },
  data () {
    return {
      msg: ''
    }
  }
}
</script>

<style scoped lang="scss">
</style>
