<template>
  <div class="index">
    <h1>Example</h1>
    <el-button @click="changeLanguage">Change Language</el-button>
    <el-button type="primary" @click="login">登录</el-button>
    <div class="demo-input-suffix">
      <span>选择日期</span>
      <el-date-picker v-model="date"
        type="date" placeholder="选择日期">
      </el-date-picker>
    </div>
    <div class="demo-input-suffix">
      <span>{{string.example.name}}</span>
      <el-input
        :placeholder="`${string.example.name}`"
        prefix-icon="el-icon-search"
        v-model="name">
      </el-input>
    </div>
    <div class="demo-input-suffix">
      <span>内容</span>
      <el-upload
        class="avatar-uploader"
        id="avatar-uploader"
        style="display: none;"
        :action="serverUrl"
        name="image"
        :data="uploadParam"
        :headers="header"
        :show-file-list="false"
        :on-success="uploadSuccess"
        :on-error="uploadError"
        :before-upload="beforeUpload">
      </el-upload>
      <quill-editor
        v-model="infoForm.content"
        ref="myQuillEditor"
        class="editer"
        :options="infoForm.editorOption" @ready="onEditorReady($event)">
      </quill-editor>
    </div>
    <el-button type="primary" @click="onSubmit">获取输入</el-button>
  </div>
</template>

<script>
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'
import { quillEditor } from 'vue-quill-editor'

import config from '@/service/config'
import store from '../../store'
import { mapGetters, mapActions } from 'vuex'
// 工具栏配置
const toolbarOptions = [
  ['bold', 'italic', 'underline', 'strike'], // toggled buttons
  ['blockquote', 'code-block'],
  [{'header': 1}, {'header': 2}], // custom button values
  [{'list': 'ordered'}, {'list': 'bullet'}],
  [{'script': 'sub'}, {'script': 'super'}], // superscript/subscript
  [{'indent': '-1'}, {'indent': '+1'}], // outdent/indent
  [{'direction': 'rtl'}], // text direction
  [{'size': ['small', false, 'large', 'huge']}], // custom dropdown
  [{'header': [1, 2, 3, 4, 5, 6, false]}],
  [{'color': []}, {'background': []}], // dropdown with defaults from theme
  [{'font': []}],
  [{'align': []}],
  ['link', 'image'],
  ['clean'] // remove formatting button
]
export default {
  name: 'Example',
  computed: {
    ...mapGetters([
      'string'
    ])
  },
  components: {
    quillEditor
  },
  data () {
    return {
      date: '',
      name: '',
      quillUpdateImg: false, // 根据图片上传状态来确定是否显示loading动画，刚开始是false,不显示
      serverUrl: config.baseURL + '/v1/images', // 这里写你要上传的图片服务器地址
      header: {Authorization: store.state.global.token}, // 有的图片服务器要求请求头需要有token之类的参数，写在这
      uploadParam: {
        type: 'signature'
      },
      imageUrl: '',
      infoForm: {
        content: '',
        editorOption: {
          placeholder: '',
          theme: 'snow', // or 'bubble'
          modules: {
            toolbar: {
              container: toolbarOptions, // 工具栏
              handlers: {
                'image': function (value) {
                  if (value) {
                    document.querySelector('#avatar-uploader input').click()
                  } else {
                    this.quill.format('image', false)
                  }
                }
              }
            }
          }
        }
      }
    }
  },
  created () {
  },
  methods: {
    ...mapActions([
      'changeLang',
      'setToken'
    ]),
    changeLanguage () {
      this.changeLang(store.state.global.lang == 'en' ? 'cn' : 'en')
    },
    login () {
      let params = {
        grant_type: 'password',
        client_id: 2,
        client_secret: 'uoajM7dTYHt14ClEalXtIl6Q5XvFmG5svNTa159E',
        username: '18999999999',
        password: '123456'
      }
      this.$api.post('v1/oauth/token', params).then((data) => {
        this.setToken(`${data.token_type} ${data.access_token}`)
        this.$openMessage({message: 'Login Success!', type: 'success'})
      }).catch(e => {
        this.$openMessage({message: 'Login Fail! Account or password error'})
      })
    },
    onSubmit () {
      let param = {
        content: this.infoForm.content
      }
      console.log(param)
    },
    onEditorReady (editor) {
    },
    // 上传图片前
    beforeUpload (file) {
      // 显示loading动画
      this.quillUpdateImg = true
      const isLt2M = file.size / 1024 / 1024 < 2
      if (!isLt2M) {
        this.$openMessage({message: 'Image size can not exceed 2mb.'})
      }
      return isLt2M
    },
    uploadSuccess (res, file) {
      // 如果上传成功
      if (res.url !== null) {
        let url = config.baseURL.replace('/v1', '') + res.url
        // 获取富文本组件实例
        let quill = this.$refs.myQuillEditor.quill
        // 获取光标所在位置
        let length = quill.getSelection().index
        // 插入图片  res.info为服务器返回的图片地址
        quill.insertEmbed(length, 'image', url)
        // 调整光标到最后
        quill.setSelection(length + 1)
      } else {
        this.$openMessage({message: 'Failed to add picture.'})
      }
      // loading动画消失
      this.quillUpdateImg = false
    },
    // 富文本图片上传失败
    uploadError () {
      // loading动画消失
      this.quillUpdateImg = false
      this.$message.error('图片插入失败')
    }
  }
}
</script>

<style scoped lang="scss">
h1 {
  margin: 0;
}
.editer {
  display: inline-block;
  width: 600px;
  background-color: #fff;
}
.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload input {
  display: none;
}
.avatar-uploader .el-upload:hover {
  border-color: #20a0ff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
.demo-input-suffix {
  margin-bottom: 15px;
  & span{
    display: inline-block;
    width: 100px;
  }
}
.el-input {
  width: 200px;
}
.el-button {
  margin-bottom: 15px;
}
</style>
