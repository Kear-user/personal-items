<template>
  <div class="">
    <el-menu class="el-menu-demo" mode="horizontal">
      <el-menu-item index="1" @click="toPath('example')">首页</el-menu-item>
      <el-menu-item index="2" @click="toPath('example')">个人中心</el-menu-item>
      <el-menu-item index="3" @click="toPath('index')">订单管理</el-menu-item>
    </el-menu>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: ''
    }
  },
  methods: {
    toPath (path) {
      if (path) {
        this.$router.replace('/' + path)
      }
    }
  }
}
</script>

<style scoped lang="scss">
</style>
