<template>
  <div class="">i'm Footer</div>
</template>

<script>
export default {
  name: 'Footer',
  data () {
    return {
      msg: ''
    }
  }
}
</script>

<style scoped lang="scss">
</style>
