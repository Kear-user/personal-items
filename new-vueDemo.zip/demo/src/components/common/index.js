import Loading from './Loading'
import Error from './Error'

export {
  Error,
  Loading
}
