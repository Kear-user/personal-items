/**
 * 选择语言
 */
import * as types from '../mutation_types.js'
import langs from '../../assets/lang'
import ls from 'store2'
import api from '@/service'

const state = {
  lang: ls.get('lang') || 'en',
  token: sessionStorage.getItem('token') || '',
  brands: [],
  fixData: {
    other: 'Other'
  },
  info: ls.get('info') || {} // 用户信息
}
state.string = langs[state.lang]
const mutations = {
  [types.CHANGE_LANG] (state, lang) {
    state.string = langs[lang]
    state.lang = lang
    ls.set('lang', lang)
  },
  [types.SET_TOKEN] (state, token) {
    state.token = token
    sessionStorage.setItem('token', token)
    // ls.set('token', token)
  },
  [types.CLEAR_TOKEN] (state) {
    state.token = ''
    sessionStorage.removeItem('token')
  },
  [types.GET_BRAND] (state, brands) {
    state.brands = brands
  },
  [types.SET_INFO] (state, info) {
    state.info = info
    ls.set('info', info)
  }
}

const actions = {
  changeLang ({ commit }, lang) {
    commit(types.CHANGE_LANG, lang)
  },
  setToken ({ commit }, token) {
    commit(types.SET_TOKEN, token)
  },
  clearToken ({ commit }) {
    commit(types.CLEAR_TOKEN)
  },
  setInfo ({ commit }, info) {
    commit(types.SET_INFO, info)
  },
  async getBrand ({ commit }) {
    let brands = await api.get(`v1/brands`)
    commit(types.GET_BRAND, brands)
  }
}

const getters = {
  lang: state => state.lang,
  string: state => state.string,
  token: state => state.token,
  brands: state => state.brands,
  fixData: state => state.fixData,
  info: state => state.info
}

export default {
  state,
  mutations,
  actions,
  getters
}
