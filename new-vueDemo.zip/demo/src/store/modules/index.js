/**
 * Vue Module 整合
 */
import global from './global'

export default {
  global
}
