/**
 * 语言
 */
export const CHANGE_LANG = 'CHANGE_LANG'

// 设置用户信息
export const SET_INFO = 'SET_INFO'
// 设置TOKEN
export const SET_TOKEN = 'SET_TOKEN'
// 清空TOKEN
export const CLEAR_TOKEN = 'CLEAR_TOKEN'
// 获取所有的品牌
export const GET_BRAND = 'GET_BRAND'
