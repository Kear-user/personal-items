// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import { Notification, Button, Input, Select, Option, DatePicker, Upload, MessageBox, Menu, MenuItem } from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import 'nprogress/nprogress.css'
import App from './App.vue'
import router from './router'
import api from './service'
import store from './store'
import { sync } from 'vuex-router-sync'

// en / zh-CN
import lang from 'element-ui/lib/locale/lang/en'
import locale from 'element-ui/lib/locale'
// 设置语言
locale.use(lang)

sync(store, router)

// 引用element-ui模块
Vue.use(Button)
Vue.use(Input)
Vue.use(Select)
Vue.use(Option)
Vue.use(DatePicker)
Vue.use(Upload)
Vue.use(Menu)
Vue.use(MenuItem)

Vue.prototype.$api = api
Vue.prototype.$confirm = MessageBox.confirm
Vue.prototype.$openMessage = ({message = '', type = 'error', title = 'Kindly Reminder'}) => {
  if (message instanceof Array) {
    for (let item of message) {
      Notification({title, item, type})
    }
  } else {
    Notification({title, message, type})
  }
}

router.beforeEach((to, from, next) => {
  if (to.meta.auth) {
    if (store.state.global.token === '') {
      next()
    } else {
      if (undefined !== from.path) {
        next(from.path)
      } else {
        next('/index')
      }
    }
  } else {
    if (store.state.global.token === '') {
      next()
      // next('/example')
    } else {
      next()
    }
  }
})

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})
