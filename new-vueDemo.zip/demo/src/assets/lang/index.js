import cn from './cn'
import en from './en'

export default {
  cn,
  en
}
