export default {
  author: 'Leo',
  common: {
    logout: 'Logout'
  },
  example: {
    name: 'Name'
  }
}
