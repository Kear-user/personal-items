export default {
  author: '俊',
  common: {
    logout: '退出'
  },
  example: {
    name: '姓名'
  }
}
